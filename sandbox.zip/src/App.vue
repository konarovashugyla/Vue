<script>
export default {
  data() {
    return {
      products: [
        {
          id: 1,
          name: "Роза",
          description: "Красные розы",
          price: 1000,
          image: "URL_ТВОЕЙ_ФОТО_РОЗЫ"
        },
        {
          id: 2,
          name: "Тюльпан",
          description: "Желтые тюльпаны",
          price: 1500,
          image: "URL_ТЮЛЬПАНА"
        }
      ]
    };
  }
};
</script>



<template>
  <div id="app">
    <header>
      <h1>Цветочный магазин</h1>
    </header>
    <section class="categories">
      <button>Розы</button>
      <button>Тюльпаны</button>
      <button>Лилии</button>
    </section>
    <section class="products">
      <div class="product-card" v-for="product in products" :key="product.id">
        <img :src="product.image" alt="Фото цветка" />
        <h3>{{ product.name }}</h3>
        <p>{{ product.description }}</p>
        <p>{{ product.price }} KZT</p>
      </div>
    </section>
  </div>
</template>


<style scoped>
.logo {
  height: 6em;
  padding: 1.5em;
  will-change: filter;
  transition: filter 300ms;
}
.logo:hover {
  filter: drop-shadow(0 0 2em #646cffaa);
}
.logo.vue:hover {
  filter: drop-shadow(0 0 2em #42b883aa);
}
</style>
